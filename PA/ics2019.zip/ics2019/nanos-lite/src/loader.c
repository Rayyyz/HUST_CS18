#include "proc.h"
#include <elf.h>
#include <fs.h>

#ifdef __ISA_AM_NATIVE__
# define Elf_Ehdr Elf64_Ehdr
# define Elf_Phdr Elf64_Phdr
#else
# define Elf_Ehdr Elf32_Ehdr
# define Elf_Phdr Elf32_Phdr
#endif

size_t ramdisk_read(void *buf, size_t offset, size_t len);
int fs_open(const char *pathname, int flags, int mode);
int fs_close(int fd);
size_t fs_read(int fd, void* buf, size_t len);
size_t fs_lseek(int fd, size_t offset, int whence);

static uintptr_t loader(PCB *pcb, const char *filename) {
  // --------pa3.3-------
  Elf_Ehdr header;
  int fd = fs_open(filename, 0, 0);
  fs_lseek(fd, 0, SEEK_SET);
  fs_read(fd, &header, sizeof(header));
  for(int i=0; i<header.e_phnum; i++){
    Elf_Phdr buf;
    fs_lseek(fd, header.e_phoff+i*header.e_phentsize, SEEK_SET);
    fs_read(fd, &buf, sizeof(buf));
    if(buf.p_type == PT_LOAD){
      fs_lseek(fd, buf.p_offset, SEEK_SET);
      fs_read(fd, (void*)buf.p_vaddr, buf.p_filesz);
      memset((void*)(buf.p_vaddr+buf.p_filesz), 0, buf.p_memsz-buf.p_filesz);
    }
  }
  // fs_close(fd);
  return header.e_entry;
  // -------PA3.2-------
  // Elf_Ehdr header;
  // ramdisk_read(&header, 0, sizeof(header));
  // for(int i=0; i<header.e_phnum; i++){
  //   Elf_Phdr buf;
  //   ramdisk_read(&buf, header.e_phoff+i*header.e_phentsize, sizeof(buf));  
  //   if(buf.p_type == PT_LOAD){
  //     ramdisk_read((void*)buf.p_vaddr, buf.p_offset, buf.p_filesz);
  //     memset((void*)(buf.p_vaddr+buf.p_filesz), 0, buf.p_memsz-buf.p_filesz);
  //   }
  // }
  // return header.e_entry;
}

void naive_uload(PCB *pcb, const char *filename) {
  uintptr_t entry = loader(pcb, filename);
  Log("Jump to entry = %x", entry);
  ((void(*)())entry) ();
}

void context_kload(PCB *pcb, void *entry) {
  _Area stack;
  stack.start = pcb->stack;
  stack.end = stack.start + sizeof(pcb->stack);

  pcb->cp = _kcontext(stack, entry, NULL);
}

void context_uload(PCB *pcb, const char *filename) {
  uintptr_t entry = loader(pcb, filename);

  _Area stack;
  stack.start = pcb->stack;
  stack.end = stack.start + sizeof(pcb->stack);

  pcb->cp = _ucontext(&pcb->as, stack, stack, (void *)entry, NULL);
}
