#include "common.h"

_Context* do_syscall(_Context *c);

static _Context* do_event(_Event e, _Context* c) {
  switch (e.event) {
    case _EVENT_NULL:
      printf("Error event[%d]: null.\n", e.event);
      break;
    case _EVENT_ERROR:
      printf("Error event[%d]: error.\n", e.event);
      break;
    case _EVENT_IRQ_TIMER:
      printf("Error event[%d]: timer.\n", e.event);
      break;
    case _EVENT_IRQ_IODEV:
      printf("Error event[%d]: io.\n", e.event);
      break;
    case _EVENT_PAGEFAULT:
      printf("Error event[%d]: pagefault.\n", e.event);
      break;
    case _EVENT_YIELD:
      printf("Error event[%d]: yield.\n", e.event);
      break;
    case _EVENT_SYSCALL:
      do_syscall(c);
      break;
    default:panic("Unhandled event ID = %d", e.event); break;
  }
  return NULL;
}

void init_irq(void) {
  Log("Initializing interrupt/exception handler...");
  _cte_init(do_event);
}
