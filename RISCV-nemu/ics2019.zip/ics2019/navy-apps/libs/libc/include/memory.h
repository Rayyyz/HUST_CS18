#ifndef _MEMORY_H
#define	_MEMORY_H
#include <string.h>
#endif /* !_MEMORY_H */
