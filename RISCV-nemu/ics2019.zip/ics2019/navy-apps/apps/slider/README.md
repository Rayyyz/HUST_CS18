# Slider

1. copy slides.pdf to `slides/`
2. run `convert.sh`
